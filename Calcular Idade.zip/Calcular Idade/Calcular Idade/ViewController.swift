//
//  ViewController.swift
//  Calcular Idade
//
//  Created by user151562 on 3/31/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    enum AgeError: Error {
        case emptyText
        case invalidFormat
        case invalidDate
        case futureBirthDay
        case unknow
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var DgIdade: UITextField!
    
    @IBOutlet weak var MostIdade: UILabel!
    
    @IBAction func CalcIdade(_ sender: Any) {
        
        do {
            let age = try calculateAge(from: DgIdade.text ?? "", dateFormat: "dd/MM/yyyy")
            MostIdade.text = String(age)
        }
        catch AgeError.emptyText{
            MostIdade.text = "Texto em Branco"
        }
        catch AgeError.futureBirthDay{
            MostIdade.text = "Data Futura"
        }
        catch AgeError.invalidFormat{
            MostIdade.text = "Formato Inválido"
        }
        catch AgeError.invalidDate{
            MostIdade.text = "Data Inválida"
        }
        catch {
            MostIdade.text = "Erro desconhecido"
        }
        
    }
    
    private func calculateAge(from text: String?, dateFormat: String) throws -> Int {
        do {
            if let _text = text {
                
                let dateFormatter = DateFormatter()
                dateFormatter.locale = Locale(identifier: "pt_BR")
                dateFormatter.dateFormat = dateFormat
                
                if let birthday = dateFormatter.date(from: _text) {
                    
                    let now = Date()
                    guard birthday <= now else { throw AgeError.futureBirthDay }
                    
                    if let age = Calendar.current.dateComponents([.year], from: birthday, to: now ).year {
                        return age
                    } else {
                        throw AgeError.invalidDate
                    }
                    
                } else{
                    throw AgeError.invalidFormat
                }
                
            } else { throw AgeError.emptyText }
        } catch {
            throw AgeError.unknow
        }
    }
    }

