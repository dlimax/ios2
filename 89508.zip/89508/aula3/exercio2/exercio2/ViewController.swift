//
//  ViewController.swift
//  exercio2
//
//  Created by user151562 on 3/26/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dgdata: UITextField!
    @IBOutlet weak var dgButtom: UIButton!
    @IBOutlet weak var dgIdate: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func dgButtom(_ sender: Any) {
        do {
            let age = try CalculateAge(from: dgdata.text ?? "", dateFormat: "dd/MM/yyyy")
            dgIdate.text = String(age)
        }
        catch AgeError.emptyText{
            dgIdate.text = "Campo Vazio"
        }
        catch AgeError.futureBirthday{
            dgIdate.text = "Data Futura"
        }
        catch AgeError.invalidFormat{           dgIdate.text = "Formto Inválido"
        }
        catch AgeError.invalidDate{
            dgIdate.text = "Data Inválida"
        }
        catch {
            dgIdate.text = "Erro !"
        }
    }

    
    private func CalculateAge(from text: String, dateFormat: String    ) throws -> Int{
        if text.isEmpty{
            throw AgeError.emptyText
        }
        
        if text.count != dateFormat.count{
            throw AgeError.invalidFormat
        }
        
        let cFormatDt = DateFormatter()
        cFormatDt.locale = Locale(identifier: "pt_BR")
        cFormatDt.dateFormat =  dateFormat
        
        let data = cFormatDt.date(from: text)
        
        if data == nil {
            throw AgeError.invalidDate
        }
        
        if data! > Date(){
            throw AgeError.futureBirthday
        }
        
        let age = Calendar.current.dateComponents([Calendar.Component.year], from: data!, to: Date()).year
        
        if age == nil{
            throw AgeError.unknown
        }
        
        return age!
    }
    
}

enum AgeError: Error {
    case emptyText
    case invalidFormat
    case invalidDate
    case futureBirthday
    case unknown
}

