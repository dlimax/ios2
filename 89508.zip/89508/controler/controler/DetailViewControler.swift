//
//  DetailViewControler.swift
//  controler
//
//  Created by user151562 on 4/6/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import Foundation
import UIKit

class DetailViewControler: UIViewController {
    override func viewDidLoad() {
     super.viewDidLoad()	

}
