//
//  DetailViewController.swift
//  controler
//
//  Created by user151562 on 4/6/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController:ViewController{
 
    @IBOutlet weak var DetailLabel: UILabel!
    var Detailtext:String?
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        DetailLabel.text=Detailtext
        			
    }
}
