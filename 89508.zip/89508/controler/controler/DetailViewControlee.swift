//
//  DetailViewControlee.swift
//  controler
//
//  Created by user151562 on 4/6/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import Foundation
