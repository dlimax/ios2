//
//  ViewController.swift
//  tableview_aula05
//
//  Created by user151562 on 4/2/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit

struct Todo : Codable{
    var task:String
    var isCompleted:Bool = false
    var id: Int?
    
    init(task: String){
        self.task = task
        self.isCompleted = false
    }
}
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet var tableView: UITableView!
    
    var items: [Todo] = []
    let todoRepository = TodoRepository(network: NetworkService(baseUrl: "https://puc-dam-todolist.herokuapp.com"), token: "W1wD5C9W05RYM9BrdT5GRVxDa7NqBSmct8eZ9l27pFE=")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(TodoItemCell.self, forCellReuseIdentifier: "todoItem")
        
        todoRepository.all{ (result) in
            switch result{
            case .success(let todos):
                self.items = todos
                self.tableView.reloadData()
         case .error:
                print("Erro na hora de buscar")
                self.items.removeAll(keepingCapacity: false)
            }
        }
        
    }
    
        
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "todoItem", for: indexPath) as? TodoItemCell else { fatalError() }
        
        cell.textLabel?.text = items[indexPath.row].task
        cell.isCompleted = items[indexPath.row].isCompleted
        return cell
    }
    
 
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //items[indexPath.row].isCompleted.toggle()
        //tableView.reloadData()
        
        items[indexPath.row].isCompleted = items[indexPath.row].isCompleted ? false : true
        
        let itemTemp = items[indexPath.row]
        
        items.remove(at: indexPath.row)
        items.insert(itemTemp, at: indexPath.row)
        
        tableView.reloadRows(at: [indexPath], with: .fade)
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let removeAction = UIContextualAction(
            style: .destructive,
            title: "Remover",
            handler: {(action, view, completionHandler) in
                
                self.items.remove(at: indexPath.row)
                self.tableView.reloadData()
                completionHandler(true)
        })
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [removeAction])
        
        return swipeConfiguration
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let removeAction = UIContextualAction(
            style: .normal,
            title: self.items[indexPath.row].isCompleted ? "Desmarcar" : "Marcar",
            handler: {(action, view, completionHandler) in
                
                self.items[indexPath.row].isCompleted = self.items[indexPath.row].isCompleted ? false : true
                
                let itemTemp = self.items[indexPath.row]
                
                self.items.remove(at: indexPath.row)
                self.items.insert(itemTemp, at: indexPath.row)
                
                //tableView.reloadData()
                tableView.reloadRows(at: [indexPath], with: .fade)
                completionHandler(true)
        })
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [removeAction])
        
        return swipeConfiguration
    }
    
    @IBAction func IncluirItem(_ sender: Any) {
        let alertController = UIAlertController(title: "Nova tarefa", message: "Digite a nova tarefa", preferredStyle: .alert)
        
        alertController.addTextField {
            (textField) in textField.placeholder = "Tarefa"
        }
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: {
            _ in guard let task = alertController.textFields?.first?.text else { return }
            print(task)
            self.todoRepository.create(taskTitle: task, callback: { (result) in
                switch result{
                case .success(let itemTemp):
                    print(itemTemp)
                    self.items.append(itemTemp)
                    self.tableView.reloadData()
                case .error:
                    print("Erro no insert")
                    self.items.removeAll(keepingCapacity: false)
                }
            })
        })
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
        
    }
}

