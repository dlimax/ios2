//
//  ViewController.swift
//  tableview_aula05
//
//  Created by user151562 on 4/2/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(TodoItemCell.self,
                           forCellReuseIdentifier: "todoItem")
    }
    
    struct Todo {
        var task : String
        var isCompleted : Bool
        
        init(task: String){
            self.task = task
            self.isCompleted = false
        }
    }
    
    var items: [Todo] = [
        Todo(task: "Terminar Exercícios de iOS"),
        Todo(task: "Trocar android por um iPhone"),
        Todo(task: "Comprar um Macbook"),
    ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "todoItem", for: indexPath) as? TodoItemCell else { fatalError() }
        
        cell.textLabel?.text = items[indexPath.row].task
        cell.isCompleted = items[indexPath.row].isCompleted
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        items[indexPath.row].isCompleted.toggle()
        tableView.reloadData()
        
    }

  
}

extension ViewController : UITableViewDelegatedo {
    
}
