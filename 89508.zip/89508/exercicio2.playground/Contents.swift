import UIKit

enum BankOperation{
    case withdrawl(value: Double)
    case deposit(from: String, value: Double)
}

enum BankAcmovimError: Error{
    case insuficientFunds(currentBalance: Double)
}

protocol BankAcmovimProtocol{
    init(number: String, holder:String)
    
    var balance: Double{ get }
    var statement: [BankOperation] {get}
    
    func withdrawl(value: Double) throws
    func deposit(value: Double, from acmovim: String)
    func formattedStatement() -> String
}



class MyBank: BankAcmovimProtocol {
    private let number: String
    private let holder: String
    private(set) var balance: Double
    private(set) var statement: [BankOperation]
    
    required init(number: String, holder:String){
        self.number = number
        self.holder = holder
        self.balance = 0.0
        self.statement = []
    }
    
    func withdrawl(value: Double) throws{
        guard balance >= value else { throw BankAcmovimError.insuficientFunds(currentBalance: self.balance)}
        
        balance = balance - value;
        statement.append(.withdrawl(value: value))
    }
    func deposit(value: Double, from acmovim: String){
        balance = balance + value;
        statement.append(.deposit(from: acmovim, value: value))
    }
    func formattedStatement() -> String{
        var result = "Movimentacao da conta \(number) - Titular \(holder):\n\n"
        for register in statement{
            switch register {
            case .deposit(let from, let value):
                result += ("DEP  \(value)    \(from)\n")
            case .withdrawl(let value):
                result += ("WTD  \(value)\n")
            }
        }
        return result;
    }
}

//Operações para testar o deposito, saque e extrato da conta.
let movim = MyBank(number: "18090-1", holder: "Jose Maria Soares")

movim.deposit(value: 90, from: "1421")

do {
    try movim.withdrawl(value: 10)
}catch BankAcmovimError.insuficientFunds {
    print ("Não existe saldo suficiente na conta para realizar a operação de saque.")
}

do {
    try movim.withdrawl(value: 60)
}catch BankAcmovimError.insuficientFunds {
    print ("Não existe saldo suficiente na conta para realizar a operação de saque.")
}

movim.deposit(value: 5, from: "090-1")

print(movim.formattedStatement())
