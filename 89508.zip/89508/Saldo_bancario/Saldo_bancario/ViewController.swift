//
//  ViewController.swift
//  Saldo_bancario
//
//  Created by user151562 on 3/31/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var LcHisto: UITextField!
    
    @IBOutlet weak var LcCredit: UITextField!
    
    @IBOutlet weak var LcDebito: UITextField!
    
    @IBOutlet weak var HistLanc: UITextView!
    
    @IBAction func AtuaMovim(_ sender: Any) {
        let count = MyBank(number: "115440-1", holder: "Jose Marcos Silva")
        
        count.deposit(value: Double(LcCredit.text!) as! Double, from: LcHisto.text!)
       
        do {
            try count.withdrawl(value: Double(LcDebito.text!) as! Double)
            
        } catch BankAccountError.insuficientFunds {
            print ("Não existe saldo suficiente na conta para realizar a operação de saque.")
        }
        
}
    
    

    
}

enum BankOperation {
    case withdrawl(value: Double)
    case deposit(from: String, value: Double)
}

public enum BankAccountError: Error{
    case insuficientFunds(currentBalance: Double)
}
protocol BankAccountProtocol{
    
    init(number: String, holder: String)
    
    var balance: Double {get}
    var statement: [BankOperation]{get}
    
    func withdrawl(value: Double) throws
    func deposit(value: Double, from account: String)
    func formattedStatement()-> String
    
    
}

class MyBank: BankAccountProtocol{
    required init(number: String, holder: String) {
        self.number = number
        self.holder = holder
        self.balance = 0.0
        self.statement = []
    }
    
    private let number: String
    private let holder: String
    private (set) var balance: Double
    private (set) var statement: [BankOperation]
    
    func withdrawl(value: Double) throws {
        if value <= balance {
            balance = balance - value
            statement.append(.withdrawl(value: value))
        }else{
            throw BankAccountError.insuficientFunds(currentBalance: balance)
        }
    }
    
    func deposit(value: Double, from account: String) {
        balance = balance + value
        statement.append(.deposit(from: account, value: value))
    }
    
    func formattedStatement() -> String {
        var texto = """
                    OPERATION    VALUE    FROM \n
                    """
        for linha in statement{
            switch linha{
            case .deposit(let from, let value):
                texto+="""
                DEP          \(value)     \(from) \n
                """
                
            case .withdrawl(let value):
                texto+="""
                WDT          \(value) \n
                """
            }
            
        }
        
        return texto
    }
    
}
