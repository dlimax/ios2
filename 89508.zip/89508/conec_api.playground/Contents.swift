import UIKit

struct Todo: Codable, CustomDebugStringConvertible{
    let userID: Int
    let id: Int
    let title: String
    let isCompleted: Bool
    
    enum CodingKeys: String, CodingKey{
        case userID = "userId"
        case id
        case title
        case isCompleted = "completed"
    }
    
    var debugDescription: String {
        return "\n(\(title) - \(id))"
    }
}

let session = URLSession.shared
let url: URL = URL(string: "https://jsonplaceholder.typicode.com/todos")!
var request = URLRequest(url:url)


//let todo = Todo(userID: 1, id : 1, title:"", isCompleted: false)
//request.httpbody = try JSONEnconder().encode(todo)
//request.addValue("Content-Type", forHTTPHeaderField: "application/json")

let task  = session.dataTask(with:request) {
    (data, response, error) in
    guard let data = data else{return}
    do{
        let todo = try JSONDecoder().decode([Todo].self, from: data)
        print(todo)
    }catch{
        print(error)
    }
    
}

task.resume()
