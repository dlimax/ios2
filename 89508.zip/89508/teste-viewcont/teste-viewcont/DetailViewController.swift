//
//  DetailViewController.swift
//  teste-viewcont
//
//  Created by user151562 on 4/7/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController:ViewController{
    
    @IBOutlet weak var detailLabel: UILabel!
    	var Detailtext:String?
    	
    override func viewDidLoad() {
        
        super.viewDidLoad()
        detailLabel.text=Detailtext 
        
    }
}
