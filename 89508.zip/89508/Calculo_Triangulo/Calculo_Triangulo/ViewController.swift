//
//  ViewController.swift
//  Calculo_Triangulo
//
//  Created by user151562 on 3/31/19.
//  Copyright © 2019 user151562. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var Rc1lda: UITextField!
    @IBOutlet weak var Rc2lda: UITextField!
    @IBOutlet weak var Rc1ldb: UITextField!
    @IBOutlet weak var Rc2ldb: UITextField!
    @IBOutlet weak var Rc1ldc: UITextField!
    @IBOutlet weak var Rc2ldc: UITextField!
    @IBOutlet weak var ResulTriangulo: UILabel!
    
    @IBAction func ClcTriangulo(_ sender: Any) {
        
        let resultado = Triangle(cord01:Point(x:Double(Rc1lda.text!) as! Double,y:Double(Rc2lda.text!) as! Double),cord02:Point(x:Double(Rc1ldb.text!) as! Double,y:Double(Rc2ldb.text!) as! Double),cord03:Point(x:Double(Rc1ldc.text!) as! Double,y:Double(Rc2ldc.text!) as! Double)).kind
        
        ResulTriangulo.text = "Resultado do triangulo: \(resultado)"
        
    }
    
    struct Point{
        let x: Double
        let y: Double
        
        // método calculo de distancia entre dois pontos
        func distance(from point: Point) -> Double{
            let pointX = pow(point.x - self.x, 2)
            let pointY = pow(point.y - self.y, 2)
            
            return sqrt(Double(pointX + pointY)).roundTo(places: 2)
        }
    }
    
    struct Triangle{
        
        let cord01: Point
        let cord02: Point
        let cord03: Point
        
        enum Kind{
            case equilateral
            case isosceles
            case scaleno
        }
        
        var kind: Kind{
            //calcula distancia entre AB AC BC
            let AB = abs(cord01.distance(from: cord02))
            let AC = abs(cord01.distance(from: cord03))
            let BC = abs(cord02.distance(from: cord03))
            
            //compara o tamanhos dos lados e retorna o tipo
            if(AB == AC && AB == BC){
                return .equilateral
            }
            if(AB != AC && AB != BC && AC != BC){
                return .scaleno
            }
            return .isosceles
        }
    }
}

extension Double{
    func roundTo(places: Int) -> Double{
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}
